package com.canon.model;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Task {
 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;
 private String title;
 private String description;
 private boolean completed;
 private LocalDateTime createdAt;

 // Getters and setters
}
