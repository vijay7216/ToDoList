package com.canon.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.canon.model.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> {
}