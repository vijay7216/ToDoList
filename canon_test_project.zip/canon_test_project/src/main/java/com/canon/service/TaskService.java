package com.canon.service;

import com.canon.model.Task;
import com.canon.repositories.TaskRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class TaskService {
 private final TaskRepository taskRepository;

 public TaskService(TaskRepository taskRepository) {
     this.taskRepository = taskRepository;
 }

 public List<Task> getAllTasks() {
     return taskRepository.findAll();
 }

 public Optional<Task> getTaskById(Long id) {
     return taskRepository.findById(id);
 }

 public Task createTask(Task task) {
     task.setCreatedAt(LocalDateTime.now());
     return taskRepository.save(task);
 }

 public Task updateTask(Long id, Task task) {
     task.setId(id);
     return taskRepository.save(task);
 }

 public void deleteTask(Long id) {
     taskRepository.deleteById(id);
 }
}
